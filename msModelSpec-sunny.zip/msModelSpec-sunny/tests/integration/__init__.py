"""Integration tests for speculators."""
