# Documentation

This directory contains the documentation for the msModelSpec-Dev project.

- **English docs**: [docs/en/](en/index.md)
- **中文文档**: [docs/zh/](zh/index.md)

Built using [MkDocs](https://www.mkdocs.org/) with the [Material theme](https://squidfunk.github.io/mkdocs-material/).

## Building the Documentation

```bash
mkdocs serve    # Local development with live reload
mkdocs build    # Production build to site/
```

## Configuration

See `mkdocs.yml` in the project root.