# [RFC]: 为 GLM-5.2 训练 Dense MLA 结构的 DSpark 草稿（兼容 DCP）

- **Status:** Implemented（分支 `glm5-mla-dspark`）；服务侧适配 [vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535)（open）
- **Type:** Feature / serving-compat
- **Affects:** DFlash 骨干、DSpark 导出契约、TrainConfig `--draft-arch`
- **Does not change:** DSpark Markov / 置信度头前向；GQA DSpark 反传路径
- **Companion PR:** [vllm-project/vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535) — `[Feature] Support GLM-5.2 MLA DSpark`

本文遵循 [speculators RFC 模板](https://github.com/vllm-project/speculators/issues?q=label%3ARFC)（Motivation / Proposed Change），并补充 Alternatives、Experiments 与 Limitations，便于评审。

---

## Summary

在 DFlash / DSpark 草稿上增加可选的 **Dense MLA** 解码器（`--draft-arch glm5`），使草稿注意力与 GLM-5.2 验证器共用同一套压缩 KV 页规格（`kv_lora_rank + qk_rope_head_dim`），从而在服务侧开启 **DCP（Decode Context Parallelism，解码上下文并行）** 时不再与 GQA 草稿冲突。

这不是新的投机算法：块并行 mask、双源 KV 注入、Markov 头与置信度头保持不变。变化仅在注意力实现与导出契约。

单节点 60 万条数据训练 1 epoch 后，训练 loss 收敛；GSM8K 实测平均接受长度 **5.01 / 8**（block size = 8）。

---

## Motivation

GLM-5.2 验证器使用 DeepSeek 风格的 **MLA**：K/V 先压到 `kv_lora_rank`，RoPE 只作用在 `qk_rope_head_dim` 通道，服务端按 **576-d 页**（默认 `512 + 64`）管理 KV。DCP 按该页布局切分 / 调度压缩 KV。

当前 DFlash / DSpark 默认草稿是 **Qwen3 GQA**：独立的 `q_proj` / `k_proj` / `v_proj`，按 `num_key_value_heads × head_dim` 存 KV。与 GLM-5.2 配对时：

1. **布局不一致。** 验证器页是 `(kv_lora, k_rope)`；GQA 草稿页是 per-head K/V。DCP 无法用同一套切分规则覆盖两条路径。
2. **头数语义不一致。** GQA 合成配置有时用 `hidden_size / head_dim` 改写 `num_attention_heads`。MLA 的压缩靠 LoRA rank，头数必须沿用验证器，不能这样改。
3. **RoPE 宽度不一致。** GLM `rope_interleave=true` 只旋转 `qk_rope_head_dim` 上的相邻 pair；GQA 对整个 `head_dim` 做 NeoX split-half。

结果是：GQA DSpark 可以在未开 DCP 时训练 / 跑通，但 **开启 DCP 后与 GLM-5.2 冲突**。需要一份与验证器同构的 Dense MLA 草稿（无 DSA indexer），同时保留 DFlash 的双源 KV 与块 mask。

---

## Alternatives considered

| 方案 | 结论 |
| --- | --- |
| 服务侧为 GQA 草稿单独关 DCP / 走非 MLA 页 | 大模型上 DCP 是显存与吞吐的关键路径；为草稿关 DCP 会拖累整条 serving 图，且双套 KV 规则难维护。 |
| 新算法类型（如 `glm5_dspark`） | 算法仍是 DSpark。拆类型会重复 Markov / 置信度 / 训练循环。用 `--draft-arch glm5` 切换解码器即可。 |
| 把 HF `glm5` config 直接当草稿 | `AutoConfig.for_model("glm5")` 可能解析成 HuggingFace GLM config，而不是本地草稿 config。必须固定构造 `Glm5Config`，`model_type` 升为 `glm5_dspark`。 |
| 移植 DSA indexer | GLM-5.2 验证器可带 DSA；草稿在 DFlash 块 mask 下做稠密注意力即可，indexer 与本 RFC 无关。 |

---

## Proposed Change

在现有 DFlash 骨干上换 MLA 注意力，DSpark 只改导出类名。训练入口走 sunny 的 `TrainConfig`，不把 argparse 字段硬编码进 `scripts/train.py`。

```mermaid
flowchart LR
  subgraph train [TrainConfig]
    draftArch["draft_arch glm5"]
    loraRank["q_lora_rank / kv_lora_rank"]
  end
  subgraph backbone [DFlash backbone]
    ctx["context_proj + context_norm"]
    rope["RoPE width = qk_rope_head_dim"]
    mla["Glm5DFlashMLAAttention"]
  end
  subgraph dspark [DSpark]
    markov[MarkovHead]
    conf[ConfidenceHead]
    export["architectures Glm5DSparkForCausalLM"]
  end
  draftArch --> mla
  loraRank --> mla
  ctx --> mla
  rope --> mla
  mla --> markov
  mla --> conf
  mla --> export
```

### 1. Dense MLA 层

新增 `src/speculators/models/dflash/glm5.py`：

- `Glm5Config`（`model_type=glm5_dspark`），默认锁 576-d 页：`kv_lora_rank=512`，`qk_rope_head_dim=64`。
- Q 只从 draft hidden 走 Q-LoRA（`q_a` → RMSNorm → `q_b`）；`q_lora_rank=0` 时退回全量 `q_proj`。
- K/V 对 `cat(target_context, draft)` 走 `kv_a`（`kv_lora_rank + qk_rope`）再 `kv_b`（nope + V）。
- RoPE 仅作用在 `qk_rope_head_dim`，交错 pair `(0,1), (2,3), ...`，对齐 `rope_interleave=true`。
- GLM-5.2：`v_head_dim == qk_head_dim`（256）。`v != qk` 时对 V 做 SDPA pad，属防御性兼容。

`Qwen3DFlashDecoderLayer.attention_class` 抽出，供 `Glm5DFlashDecoderLayer` 覆盖。

### 2. DFlash 接线

`dflash/core.py`：

- `is_glm5_mla_config` → `Glm5DFlashDecoderLayer`，否则仍为 Qwen3 GQA。
- Rotary cache：`deepcopy` 后 `head_dim = qk_rope_head_dim`，不改 transformer config 上的 `head_dim`。
- MLA 导出 K3 权重名 `context_proj` / `context_norm`；GQA 仍用 `fc` / `hidden_norm`。`_project_context()` 统一两条路径。
- `_no_split_modules` 增加 `Glm5DFlashDecoderLayer`。

`dflash/config.py`：`model_type in {glm5, glm5_dspark}` 一律 `Glm5Config(**dict)`，避免 `AutoConfig.for_model` 落到 HF GLM config。`--draft-config` 使用同一映射。

### 3. DSpark 导出契约

服务侧 vLLM-Ascend 按 architecture 名分发草稿（K3 对应 `K3DSparkForCausalLM`）。MLA 草稿：

- `DSparkSpeculatorConfig.architectures = ["Glm5DSparkForCausalLM"]`
- `save_pretrained` 在 HF 写回 Python 类名之后，再把 architecture 写回上述名字

Forward / Markov / 置信度头不改。**不**给置信度头加 `.detach()`（与 MLA 无关，会改变现有 GQA DSpark 反传）。

本仓库只负责训练与检查点契约。Ascend 上加载 `Glm5DSparkForCausalLM`、MLA 因果 / 非因果解码、以及 DSpark proposer 接入，由配套 PR [vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535) 完成（撰写时仍为 open）。两边约定同一导出名，训练产物可直接被该 PR 的模型类消费。

### 4. TrainConfig（sunny）

`DraftArgs` 增加：

- `draft_arch: Literal["llama", "qwen3", "glm5"] | None`
- `q_lora_rank` / `kv_lora_rank`（可选覆盖；`q_lora_rank=0` 关闭 Q-LoRA）

校验：`glm5` 仅允许 `dflash` / `dspark`；非 glm5 且未走 glm5 `--draft-config` 时禁止 LoRA rank 覆盖。

`create_transformer_layer_config`：从验证器拷贝 MLA 维，**保留**验证器 `num_attention_heads`，RoPE 解析宽度用 `qk_rope_head_dim`。

### 与 Qwen3 GQA 对照

| | Qwen3 GQA（默认） | GLM-5 Dense MLA |
| --- | --- | --- |
| 开关 | `--draft-arch qwen3` | `--draft-arch glm5` |
| Q | `q_proj` + 每头 RMSNorm | Q-LoRA（或全量 `q_proj`） |
| K/V | 独立 `k_proj` / `v_proj` | `kv_a` + `kv_b`，压缩 latent |
| 双源 KV | `cat(k_ctx, k_noise)` 等同投影 | `kv_a(cat(target, draft))` |
| RoPE | 全 `head_dim`，NeoX split-half | 仅 `qk_rope_head_dim`，交错 pair |
| 上下文投影 | `fc` / `hidden_norm` | `context_proj` / `context_norm` |
| 导出 `architectures` | `DSparkSpeculator` | `Glm5DSparkForCausalLM` |
| DCP | 与 GLM-5.2 MLA 页冲突 | 与验证器页规格对齐 |

---

## Non-goals

- 不新增投机算法类型；不改 DSpark 损失与 Markov 训练语义。
- 不实现 DSA indexer。
- 不把含集群地址的 `train-glm52-*.sh` 合入本仓库。
- 不把 `glm5` 标成已支持的通用 vLLM CUDA 草稿。Ascend 服务路径见 [vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535)，不在本 RFC 的代码范围内。

---

## Experiments

实验在 `speculators-mla` 上用与本 RFC 相同的 MLA 草稿完成（sunny 侧为同源移植）。脚本参考 `train-glm52-1node.sh` 的超参，**不**在文档中复制集群地址。

### Setup

| 项 | 值 |
| --- | --- |
| 验证器 | GLM-5.2 |
| 算法 | DSpark，`--draft-arch glm5` |
| 草稿层 | 5，全部 full attention |
| `block_size` | 8 |
| 数据 | 60 万条，1 epoch，`train-data-ratio=0.96` |
| 并行 | 单节点 16 NPU，`--fsdp-shard` |
| 优化 | `lr=5e-4`，cosine |
| 序列 | `--total-seq-len 4096`，`--max-anchors 600` |
| 损失 | `{"ce": 0.3, "tv": 0.7}`，`--dflash-decay-gamma 10` |
| 头 | `markov_rank=256`，置信度头开启 |
| 注意力实现 | `--draft-attn-impl sdpa` |
| aux 层 | `--target-layer-ids 2 22 38 58 74` |

训练约 **17 750** global step。

### 训练曲线

![815 glm5_dspark 单节点训练曲线：loss / accept_rate / accept_len](../../assets/rfc/train-1node-225-0815-1848_curves.png)

| 指标（EMA α=0.1，末步） | 值 |
| --- | --- |
| `train/loss` | 0.924 |
| `train/accept_rate` | 0.563 |
| `train/accept_len` | 3.928（训练日志中的块内接受长度；图中参考线 5.0） |

Loss 在前 ~2.5k step 快速下降后继续缓降；接受率与接受长度单调上升。训练期 `accept_len` 未到 5，与 GSM8K 服务侧统计口径不同（见下）。

### GSM8K 服务侧

同一检查点在 GSM8K 上投机解码（`block_size=8`）：

![GSM8K 投机解码指标](../../assets/rfc/accept-gsm8k.png)

| 指标 | 值 |
| --- | --- |
| Average acceptance length | **5.01 / 8** |
| Overall acceptance rate | 50.11% |
| Total drafts / draft tokens / accepted tokens | 27 314 / 218 512 / 109 502 |
| Output token throughput | 455.30 tok/s |
| Total token throughput | 510.24 tok/s |
| TPOT（不含首 token）mean / P50 | 25.46 ms / 23.30 ms |
| TTFT mean / P50 | 2051.17 ms / 555.33 ms |

逐位置接受率（slot 0–7）：

| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 87.97% | 74.72% | 62.90% | 51.91% | 42.57% | 34.06% | 26.89% | 19.89% |

块末衰减符合 DSpark「块并行 + 位置依赖变弱」的预期；平均接受长度 ≈ 5 表明 MLA 草稿在 GLM-5.2 上可用，而不仅是训练 loss 下降。

[vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535) 在 PR 描述中另报了一组 **GLM-5.2 W4A8 验证器 + MLA DSpark BF16** 的 GSM8K 子集预览（vLLM `v0.27.1`）：`acceptance_len=4.59`，逐位置接受率约 `[0.874, 0.729, 0.593, 0.479, 0.382, 0.301, 0.233]`。与上表全量 GSM8K（5.01 / 8）不是同一评测切片，但量级一致，说明训练契约与 Ascend 服务路径可以对上。

---

## Testing

单测（sunny）：

```bash
pytest tests/unit/models/test_glm5_dflash.py \
  tests/unit/train/test_cli_args.py \
  tests/unit/train/config/test_schema.py \
  tests/unit/models/test_dflash_attention.py \
  tests/unit/models/test_dspark_model_definitions.py
```

覆盖：交错 RoPE pair、MLA 权重名（`q_a` / `kv_a` / `context_proj`）、forward 有限 loss、config roundtrip（含 legacy `model_type=glm5` 升格）、`save_pretrained` 导出 `Glm5DSparkForCausalLM`、CLI/schema 对 `glm5` 的允许与拒绝。

---

## Drawbacks and limitations

- **`--draft-arch glm5` 仅 dflash / dspark。** Eagle-3 / P-EAGLE / MTP 仍用 llama / qwen3 / 原生层。
- **训练侧名字 vs 服务侧名字。** 训练可用 `glm5`；落盘 `model_type` 为 `glm5_dspark`，architecture 为 `Glm5DSparkForCausalLM`，由 [vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535) 注册加载。通用 vLLM CUDA 草稿路径尚未宣称支持。
- **无 DSA。** 草稿在 DFlash mask 下稠密注意力；与带 DSA 的 GLM-5.2 验证器并存时，indexer 只存在于验证器。
- **1 epoch / 60 万条。** GSM8K 接受长度 5/8 是该数据规模下的结果，不是上限。更长训练或领域数据可能继续抬升块后段接受率。
- **TTFT 尾部。** GSM8K 上 TTFT P99 很高，更可能来自服务批处理 / 调度，而不是 MLA 草稿本身；本 RFC 不把它当作架构回归。

---

## Open questions

1. [vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535) 合并后，是否将 `glm5_dspark` 提升为与 `qwen3` 同级的一等草稿架构，还是继续作为 GLM-5.x 专用导出？
2. 是否在更多任务（不只 GSM8K）上报告 DCP on / off 的对照，作为后续 serving RFC？
3. Q-LoRA rank 覆盖（`--q-lora-rank`）对接受长度与草稿算力的 Pareto 尚未扫描。

---

## References

- DFlash: [arXiv:2602.06036](https://arxiv.org/abs/2602.06036)
- DSpark: [arXiv:2607.05147](https://arxiv.org/abs/2607.05147)
- DeepSeek-V2 MLA: [arXiv:2405.04434](https://arxiv.org/abs/2405.04434)
- 服务侧适配：[vllm-project/vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535)（`[Feature] Support GLM-5.2 MLA DSpark`，open）
- 实现：`src/speculators/models/dflash/glm5.py`、`dflash/core.py`、`dspark/config.py`、`dspark/core.py`、`src/speculators/train/config/schema.py`、`scripts/train.py`
