# 设计文档

仓库内的设计讨论与 RFC。合并前的架构变更请按 [speculators RFC](https://github.com/vllm-project/speculators/issues?q=label%3ARFC) 的 Motivation / Proposed Change 结构撰写。

| 文档 | 状态 | 说明 |
| --- | --- | --- |
| [RFC：GLM-5.2 Dense MLA DSpark 草稿（兼容 DCP）](rfc-glm5-mla-dspark.md) | Implemented | `--draft-arch glm5`；服务侧 [vllm-ascend#14535](https://github.com/vllm-project/vllm-ascend/pull/14535) |
