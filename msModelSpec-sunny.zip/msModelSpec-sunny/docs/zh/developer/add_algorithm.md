# 添加新的投机解码算法

本指南说明如何向 Speculators 库添加新的投机解码算法。

## 快速开始

添加新算法需要：

1. **创建算法模块**，位于 `src/speculators/models` 下。

2. **配置类**，使用 `@register` 装饰器。当 Python 导入您的模块时，`@register("myalgo")` 装饰器会将您的类添加到全局注册字典中。训练脚本在注册表中查找 `"myalgo"` 以找到您的类。这很有用，因为训练脚本不需要了解每个算法，添加新算法也无需修改训练脚本。

3. **模型类**，使用 `@register` 装饰器

4. **训练工厂方法**，作为模型上的类方法

5. **CLI 参数**，在 `train.py` 中

## 分步指南

### 1. 创建算法模块

在 `src/speculators/models` 下为您的算法创建一个自包含的目录。参见 `src/speculators/models/eagle3` 作为示例。这使算法逻辑保持隔离和可维护。每个算法拥有自己的配置、模型定义和任何自定义组件。示例文件结构：

```
src/speculators/models
|-> eagle3
|-> ...
|-> new_algorithm
    |-> __init__.py
    |-> core.py
    |-> config.py
```

### 2. 实现配置类

定义算法的配置方式。配置存储超参数、架构选择和其他设置。保存模型时序列化，加载模型时反序列化。在 `config.py` 中，使用 `@register` 装饰器创建配置类，例如：

```python
from speculators import SpeculatorModelConfig

@SpeculatorModelConfig.register("myalgo")
class MyAlgoSpeculatorConfig(SpeculatorModelConfig):
    speculators_model_type: str = "myalgo"

    # 算法特定参数
    block_size: int = 8
    num_layers: int = 1
```

**参考：** 参见 `src/speculators/models/eagle3/config.py` 获取完整示例。

**关键点：**

- 使用 `@SpeculatorModelConfig.register("myalgo")` 装饰器
- 设置 `speculators_model_type` 以匹配您的算法名称
- 从 `SpeculatorModelConfig` 继承公共字段
- 根据需要添加算法特定参数

### 3. 实现模型类

定义算法的架构和训练接口。模型类包含模型架构、前向传播逻辑和训练设置。通过实现所需方法，您的算法应能无缝地与训练基础设施配合工作。

在 `core.py` 中，使用 `@register` 装饰器和所需的训练工厂方法创建模型类。

**参考：** 参见 `src/speculators/models/eagle3/core.py` 获取完整示例。

**训练基础设施所需：**

模型属性：

- `layers`：解码器层的 ModuleList（每层由 FSDP 单独包装用于分布式训练）

方法：

- `from_training_args(cls, verifier_config, **kwargs)`：从 CLI 参数构建的工厂方法
- `get_trainer_kwargs(**kwargs)`：返回传递给 `forward()` 的 `(train_kwargs, val_kwargs)` 字典
- `forward(...)`：必须返回 `(output, loss, metrics)`，其中 metrics 包含 `"loss"` 键

### 4. 导出类

使您的类可从包中导入。Python 的导入系统需要从 `__init__.py` 显式导出。这也提供了清晰的公共 API。

在 `__init__.py` 中，导出您的配置和模型类。

```python
from speculators.models.eagle3.config import Eagle3SpeculatorConfig
from speculators.models.eagle3.core import Eagle3DraftModel

__all__ = [
    "Eagle3DraftModel",
    "Eagle3SpeculatorConfig",
]
```

**参考：** 参见 `src/speculators/models/eagle3/__init__.py`

### 5. 添加 CLI 参数（可选）

向训练脚本添加算法特定的命令行参数。如果您的算法有独特的超参数（如 Eagle3 的 `--ttt-steps` 或自定义的 `--block-size`），用户需要一种从命令行配置它们的方式。这些参数将传递给您的 `from_training_args()` 方法。

**参考：** 参见 `scripts/train.py`

### 6. 训练您的模型

训练脚本应自动适用于您的新算法：

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type myalgo \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --num-layers 1 \
    --block-size 8 \
    --data-path ./output \
    --save-path ./output/checkpoints \
    --epochs 20
```

## 工作原理

**训练期间的流程：**

1. 用户运行：`python train.py --speculator-type myalgo`
2. 训练脚本调用：`model_class = SpeculatorModel.get_class("myalgo")`
3. 注册表返回：`MyAlgoDraftModel` 类
4. 脚本将参数转换为字典：`vars(args)` 并调用：`model_class.from_training_args(verifier_config, **vars(args))`
5. 您的工厂方法提取所需的 kwargs 并构建模型实例
6. 训练器验证模型已注册

这种模式类似于 `transformers` 使用 `.from_pretrained()` 的方式——每个模型拥有自己的实例化逻辑。

**参考：** 参见 `scripts/train.py`

## 使用基础组件

可在不同算法间复用的共享 Transformer 层组件。许多投机解码算法使用相似的架构组件（解码器层、注意力、归一化）。您可以从 `base_components` 导入预配置的组件，而不是重复定义代码。

**可用架构：** `llama`、`qwen3`

**参考：**

- 组件定义：`src/speculators/models/base_components.py`
- 使用示例：`src/speculators/models/eagle3/model_definitions.py`