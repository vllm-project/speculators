# 评估模型性能

本教程介绍如何评估和基准测试训练好的投机解码模型。

## 指标

- **接受率**：草稿模型提议的令牌中被目标模型接受的百分比。更高的接受率意味着更好的草稿模型质量。
- **延迟**：生成每个令牌所需的时间。与普通（非投机）生成相比，时间是投机解码的关键指标。
- **块大小**：草稿模型每次提议的令牌数量。更大的块大小可能导致更高的加速，但可能降低接受率。

## 基准测试

### 使用 vLLM 进行基准测试

vLLM 提供基准测试脚本，用于测量使用投机解码的吞吐量和延迟。

```bash
# 使用投机解码运行基准测试
python benchmark/benchmark_latency.py \
    --model meta-llama/Llama-3.1-8B \
    --speculative-model RedHatAI/Llama-3.1-8B-speculator.eagle3 \
    --num-iters 100 \
    --batch-size 1
```

### 以不同方式比较

<table>
<thead>
<tr>
<th>方法</th>
<th>延迟（每令牌毫秒）</th>
<th>接受率</th>
</tr>
</thead>
<tbody>
<tr>
<td>普通（无投机）</td>
<td>基准</td>
<td>—</td>
</tr>
<tr>
<td>Eagle-3（块大小 4）</td>
<td>比基准更好</td>
<td>~0.8</td>
</tr>
<tr>
<td>Eagle-3（块大小 6）</td>
<td>比基准更好</td>
<td>~0.7</td>
</tr>
</tbody>
</table>

## 在验证期间评估

在训练期间，验证器会计算以下指标：

- **验证损失**：在验证集上计算的损失值
- **接受率**：草稿令牌被接受的比率

这些指标可帮助您监控训练过程中的模型质量。

## 使用训练器的评估模式

您可以使用训练器的评估模式来评估训练好的检查点：

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type eagle3 \
    --data-mode offline \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./output/generated_data/val \
    --save-path ./output/checkpoints \
    --eval-only
```

## 最佳实践

- 始终使用相同的硬件和环境运行基准测试以获得公平比较
- 在多个提示上测量以减少方差
- 使用不同的块大小进行实验以找到最佳权衡
- 在训练期间监控验证损失以检测过拟合