# 训练投机者

本教程演示了使用 Speculators 训练投机解码草稿模型的端到端工作流。我们将涵盖所有三种数据模式（在线、离线、混合）和所有支持的算法。

## 总体工作流

训练投机解码器包括以下步骤：

1. 准备训练数据（可选，取决于模式）
2. 运行训练脚本

## 训练支持的模式

| 数据模式 | 数据生成 | 数据存储 | 用例 |
| --------- | ---------- | ---------- | ----- |
| 在线       | 训练期间由 vLLM 服务器按需生成 | 可选，在第一个轮次期间缓存到磁盘 | 快速原型设计；无需预生成数据 |
| 离线      | 训练前由 vLLM 服务器预生成 | 始终存储在磁盘上 | 在多个训练运行之间重用数据 |
| 混合      | 第一个轮次在线生成并缓存；后续轮次重用 | 第一个轮次后始终存储 | 结合在线和离线的优势 |

## 先决条件

- 一个支持的数据集（JSONL 格式，每行包含 `"conversation"` 或 `"messages"` 键）
- 目标（验证器）模型，如 `meta-llama/Llama-3.1-8B` 或 `Qwen/Qwen2.5-7B`
- 足够的内存（GPU）来服务目标模型（离线模式）或同时服务 + 训练（在线模式）

## 在线训练

**在线训练**在训练期间从 vLLM 服务器即时生成隐藏状态。训练器启动一个 vLLM 服务器，将批次数据发送给它，并接收用于训练的隐藏状态。第一个轮次中，数据可以可选地缓存到磁盘，以便后续轮次无需重新查询服务器。这对于快速原型设计非常有用，无需预生成数据，但需要训练和服务流水线之间仔细协调。

### 创建一个 tmux 会话

我们将使用 `tmux` 来管理进程。首先，创建一个新会话：

```bash
tmux new-session -s speculators-training
```

### 启动训练

使用 `scripts/train.py` 并指定 `--data-mode online`：

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type eagle3 \
    --data-mode online \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20
```

### 工作原理

1. 训练器从指定的数据集加载样本
2. 它在内部启动一个配置为提取隐藏状态的 vLLM 服务器
3. 对于每个批次，服务器生成隐藏状态，训练器计算损失并更新权重
4. 在第一个轮次结束时，隐藏状态可以缓存到磁盘以供后续轮次使用

### 缓存

**默认情况下，隐藏状态在第一个轮次期间缓存到磁盘**，后续轮次重用缓存的数据。这意味着只有第一个轮次查询 vLLM 服务器——后续轮次从磁盘读取缓存。要禁用此行为（例如，在数据生成中使用不同的采样参数），使用 `--no-cache-data` 标志。

## 离线训练

**离线训练**在训练之前预先计算并存储隐藏状态。这需要单独的步骤来生成数据，但使得训练过程更简单，因为训练器在训练期间不需要与 vLLM 服务器通信。

### 步骤 1：准备数据

使用 `scripts/prepare_data.py` 预处理您的数据集：

```bash
python scripts/prepare_data.py \
    --data-path ./data/sample.jsonl \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --output-path ./output/prepared_data \
    --max-seq-length 4096
```

### 步骤 2：生成隐藏状态

使用 `scripts/data_generation_offline.py` 从 vLLM 服务器生成隐藏状态：

```bash
python scripts/data_generation_offline.py \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./output/prepared_data \
    --output-path ./output/generated_data
```

### 步骤 3：训练

使用 `scripts/train.py` 并指定 `--data-mode offline`：

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type eagle3 \
    --data-mode offline \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./output/generated_data \
    --save-path ./output/checkpoints \
    --epochs 20
```

## 混合训练

**混合训练**结合了在线和离线模式的优势。它使用与在线模式相同的命令，但明确启用缓存。在第一个轮次中，数据从 vLLM 服务器生成并缓存到磁盘。在后续轮次中，训练器从磁盘读取缓存数据，无需重新查询服务器。

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type eagle3 \
    --data-mode online \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20 \
    --cache-data
```

## 检查点恢复

训练自动从最新的检查点恢复。检查点目录包含：

- `checkpoint-{step}/`：包含模型权重、优化器状态和调度器状态的完整检查点
- `best_model/`：指向最佳验证损失检查点的符号链接

要恢复训练，只需使用相同的 `--save-path` 重新运行训练命令。训练器会自动检测最新的检查点并从那里恢复。

## 算法特定参数

### Eagle-3

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type eagle3 \
    --data-mode online \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20 \
    --num-layers 4 \
    --head-dim 128 \
    --loss-fn kl_div
```

### P-EAGLE

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type peagle \
    --data-mode online \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20 \
    --num-layers 4 \
    --num-depths 4 \
    --down-sample-ratio 0.7 \
    --down-sample-ratio-min 0.2
```

### DFlash

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type dflash \
    --data-mode online \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20 \
    --block-size 6 \
    --num-layers 4 \
    --max-anchors 4
```

### DSpark

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type dspark \
    --data-mode online \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20 \
    --block-size 6 \
    --num-layers 4 \
    --max-anchors 4 \
    --markov-rank 256 \
    --markov-head-type vanilla \
    --enable-confidence-head \
    --confidence-head-alpha 1.0
```

### MTP

```bash
torchrun --nnodes=1 --nproc_per_node=8 scripts/train.py \
    --speculator-type mtp \
    --data-mode online \
    --verifier-name-or-path Qwen/Qwen3-Next-8B \
    --data-path ./data/sample.jsonl \
    --save-path ./output/checkpoints \
    --epochs 20 \
    --num-mtp-layers 3 \
    --mtp-beta 0.6
```

## 下一步

在训练投机者后，您可以：

- [在 vLLM 中服务](serve_vllm.md) 以在生产中使用它
- [评估模型性能](evaluating_performance.md) 以衡量加速效果