# 在 vLLM 中服务

本教程介绍如何使用 vLLM 服务训练好的投机解码模型。

## 快速开始

使用 `vllm serve` 命令服务一个投机者模型：

```bash
vllm serve meta-llama/Llama-3.1-8B \
    --speculative-model RedHatAI/Llama-3.1-8B-speculator.eagle3 \
    --speculative-draft-length 5 \
    --num-speculative-tokens 5
```

vLLM 自动检测投机者模型。您也可以使用 `--speculative-model` 显式指定。

## 使用 Speculators 启动脚本

使用 `scripts/launch_vllm.py` 脚本：

```bash
python scripts/launch_vllm.py \
    --verifier-name-or-path meta-llama/Llama-3.1-8B \
    --speculator-path ./output/checkpoints/best_model \
    --served-model-name my-speculator \
    --port 8000
```

## 选项

- `--speculative-model`：指定投机者模型路径或 HuggingFace 名称
- `--speculative-draft-length`：草稿令牌数
- `--num-speculative-tokens`：要生成的投机令牌数

## 验证

服务启动后，使用 `curl` 验证：

```bash
curl http://localhost:8000/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "my-speculator",
        "messages": [
            {"role": "user", "content": "Hello, how are you?"}
        ]
    }'
```

## 生产部署

对于生产环境，考虑：

- 使用多个 GPU 进行张量并行
- 启用请求批处理
- 监控延迟和吞吐量

## 转换模型

如果您的模型来自第三方仓库（EAGLE v1/v2/v3、HASS），使用转换脚本将其转换为 Speculators 格式，以便直接部署到 vLLM。

```bash
python scripts/convert_eagle.py \
    --checkpoint-path /path/to/eagle/checkpoint \
    --output-path ./output/converted \
    --verifier-name-or-path meta-llama/Llama-3.1-8B
```

## 参见

- [vLLM 文档](https://docs.vllm.ai/en/latest/features/spec_decode.html) — 投机解码的完整 vLLM 指南
- [vLLM Recipes](https://recipes.vllm.ai/) — 使用 vLLM 服务投机者的部署命令库