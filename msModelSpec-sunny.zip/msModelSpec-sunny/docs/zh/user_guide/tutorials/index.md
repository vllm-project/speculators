# 教程

欢迎来到 Speculators 教程！这些分步指南将帮助您执行端到端的投机解码工作流。

## 教程列表

- [训练投机者](train.md) — 学习如何为您的目标模型训练投机解码草稿模型
- [响应重新生成](response_regeneration.md) — 使用 vLLM 模型的响应重新生成数据集以提高训练数据质量
- [评估模型性能](evaluating_performance.md) — 了解如何评估和基准测试训练好的投机解码器
- [在 vLLM 中服务](serve_vllm.md) — 使用 vLLM 部署训练好的投机者模型