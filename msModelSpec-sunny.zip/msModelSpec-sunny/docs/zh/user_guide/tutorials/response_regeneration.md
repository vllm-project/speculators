# 响应重新生成

响应重新生成通过使用 vLLM 生成新的响应来迭代细化训练数据。这有助于提高训练数据的质量和多样性，从而提升最终投机解码器的性能。

## 什么时候需要？

- 您的训练数据包含来自更弱模型或人工标注的响应，您希望使用更强大的模型进行升级
- 您想增加训练数据的多样性
- 您需要重新生成特定数据字段（如 `chosen`、`rejected`、`response`）

## 工作原理

工作流有两个步骤：

1. 使用来自 vLLM 服务器的模型重新生成 JSONL 数据集中指定字段的响应
2. 将新响应与原始数据合并，并可选地过滤掉低质量样本

## 使用方法

### 步骤 1：响应重新生成

使用 `scripts/response_regeneration` 脚本。该脚本使用 vLLM 服务器重新生成数据集中的响应。

```bash
python scripts/response_regeneration/regenerate.py \
    --input-path ./data/original.jsonl \
    --output-path ./data/regenerated.jsonl \
    --model-name-or-path meta-llama/Llama-3.1-8B \
    --target-field chosen \
    --max-model-len 4096 \
    --tensor-parallel-size 8
```

### 步骤 2：合并（可选）

使用 `scripts/response_regeneration/merge.py` 将原始数据与重新生成的数据合并：

```bash
python scripts/response_regeneration/merge.py \
    --original-path ./data/original.jsonl \
    --regenerated-path ./data/regenerated.jsonl \
    --output-path ./data/merged.jsonl
```

## 过滤

响应重新生成管道可以选择过滤掉低质量样本。要启用过滤，工作流依赖于：

- 基于长度的过滤（过短或过长的响应）
- 去重（移除高度相似的响应）

## 预训练模型

预训练模型可在 HuggingFace 上从 [RedHatAI speculator models 集合](https://huggingface.co/collections/RedHatAI/speculator-models)获取。