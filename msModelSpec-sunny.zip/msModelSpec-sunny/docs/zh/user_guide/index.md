# 用户指南

欢迎使用 Speculators 用户指南。本指南将帮助您开始训练和部署投机解码模型。

## 概述

Speculators 提供了一个全面的框架，用于：

- 训练投机解码模型
- 将现有模型转换为 Speculators 格式
- 使用 vLLM 部署模型

## 快速链接

- [入门指南](getting_started.md) - 如果您是 Speculators 新手，请从这里开始
- [特性](features.md) - 核心特性的详细文档
- [损失函数](loss_functions.md) - 通过 `--loss-fn` 可用的训练损失
- [算法](algorithms/index.md) - 支持的算法概述
- [教程](tutorials/index.md) - 分步指南