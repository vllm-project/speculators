# 损失函数

训练损失控制草稿模型的优化目标。在 [`train.py`](../cli/train.md) 中使用 `--loss-fn` 选择，该参数接受单个损失名称或用于加权组合的 JSON 字典。适用于 Eagle-3、P-EAGLE、DFlash 和 DSpark。MTP 使用自己的多步交叉熵损失，忽略此标志。

```bash
python scripts/train.py ... --loss-fn kl_div
```

## 可用的损失函数

`p` 是目标分布，`q` 是草稿分布，`alpha = sum_v min(p_v, q_v)` 是分布重叠，等于投机解码的接受率。

| 名称          | 目标                                    | 说明 |
| ------------- | --------------------------------------- | ---- |
| `kl_div`      | 前向 KL，目标到草稿                      | 默认。覆盖质量：惩罚草稿遗漏目标质量。 |
| `rkl`         | 反向 KL，草稿到目标                      | 模式寻找：草稿集中在目标的主导模式上。 |
| `jsd`         | Jensen-Shannon 散度                      | 对称，有界于 `log 2`。平衡前向和反向 KL。 |
| `ce`          | 针对 `argmax p` 的交叉熵                | 来自目标的硬标签。`--per-position-loss-weight dpace` 需要。 |
| `tv`          | 总变差，`1 - alpha`                     | 直接优化接受率。重叠低时梯度消失。 |
| `nla`         | 负对数接受率，`-log(alpha)`             | TV 的目标，带有 `1 / alpha` 梯度增强，因此可以从冷启动训练。 |
| `lk_hybrid`   | 自适应 KL/TV 混合                       | `lambda * KL + (1 - lambda) * TV`，其中 `lambda = exp(-3 * alpha)`，detached。 |

`tv` 和 `nla` 在 CUDA 设备上可用时使用融合的 Triton 内核，否则回退到 eager PyTorch。

## 选择损失函数

- 从 `kl_div` 开始。它是默认值且经过最充分测试的选项。
- 要直接优化接受率，使用 `lk_hybrid` 或 `nla`。普通 `tv` 具有相同目标但在训练早期梯度较弱。
- 当需要硬标签监督或 D-PACE 位置加权时，使用 `ce`。

## 加权组合

传递 JSON 字典以在多个损失的加权和上训练。权重按原样使用，不会归一化。每个项在应用权重之前也会单独记录为 `{name}_loss`。

```bash
python scripts/train.py ... --loss-fn '{"ce": 0.1, "tv": 0.9}'
```

## 参考文献

- Lin, "Divergence measures based on the Shannon entropy" (1991) — Jensen-Shannon 散度
- Samarin et al., ["LK Losses: Direct Acceptance Rate Optimization for Speculative Decoding"](https://arxiv.org/abs/2602.23881) — `nla` 和 `lk_hybrid`