# 算法

Speculators 支持五种投机解码算法。所有算法都是无损的——它们从与目标模型相同的分布产生输出。

## [Eagle-3](algorithms/eagle3.md)

使用 Llama 风格的草稿层自回归预测草稿令牌。更成熟的算法，在 Speculators 和 vLLM 中都有成熟的支持。

## [P-EAGLE](algorithms/peagle.md)

扩展 Eagle-3，在多个深度上进行并行多令牌预测，使用 COD 采样实现内存高效训练。

## [DFlash](algorithms/dflash.md)

在单次前向传播中使用基于块的预测和 Qwen3 风格的草稿层预测所有草稿令牌。较新，支持正在快速改进。

## [DSpark](algorithms/dspark.md)

扩展 DFlash，增加了用于块内令牌依赖的 Markov 头和预测逐位置接受的置信度头。最新，支持正在快速改进。

## [MTP](algorithms/mtp.md)

在领域特定数据上微调模型的原生多令牌预测头。适用于具有内置 MTP 支持的模型（如 Qwen3-Next、Qwen3.5）。

## 选择算法

所有算法都可以与任何支持的验证器模型配对。有关选择的帮助，请参见[决策指南](algorithms/decision_guide.md)。

## 添加新算法

参见[开发者指南](../../developer/add_algorithm.md)了解向 Speculators 添加自定义算法的说明。