# Eagle-3

Eagle-3 是一种投机解码算法，使用轻量级草稿模型自回归地预测多个后续令牌，然后由目标模型在单次前向传播中验证。草稿模型使用 Llama 风格的 Transformer 层，并训练以最小化与目标模型 logits 的 KL 散度。它支持跨分词器词汇表，并且可以与任何支持的验证器模型配对。

## 工作原理

### 架构

![Eagle-3 架构](../../assets/eagle3_architecture.png)

目标模型在选定层产生隐藏状态，这些状态通过全连接层与令牌嵌入一起拼接和投影。这些通过 Llama 风格解码器层（默认：1 层）和 LM 头产生草稿 logits。在每个自回归步骤中，草稿模型接收前一个令牌的嵌入和隐藏状态来预测下一个令牌。

### 推理过程

1. Eagle-3 自回归地草拟 K 个令牌，每一步将前一个预测反馈到草稿模型
2. 目标模型在单次前向传播中验证所有 K 个草稿令牌
3. 接受最长的正确前缀
4. 从最后一个被接受的令牌重复

## 预训练模型

我们团队训练的预训练 Eagle-3 投机者模型可在 HuggingFace 上从 [RedHatAI speculator models 集合](https://huggingface.co/collections/RedHatAI/speculator-models)获取。

## 研究与引用

Eagle-3 基于 SafeAI Lab 的研究：[EAGLE 仓库](https://github.com/SafeAILab/EAGLE) | [arXiv 论文](https://arxiv.org/abs/2401.15077)

```bibtex
@article{li2024eagle,
  title={EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty},
  author={Li, Yuhui and Wei, Fangyun and Zhang, Chao and Zhang, Hongyang},
  journal={arXiv preprint arXiv:2401.15077},
  year={2024}
}
```

## 参见

- [msModelSpec-Dev 训练指南](../tutorials/train.md) — 分步训练指南
