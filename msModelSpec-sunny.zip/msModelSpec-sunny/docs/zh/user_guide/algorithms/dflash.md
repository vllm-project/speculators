# DFlash

DFlash 是一种投机解码方法，使用小型扩散-LLM 草稿模型在单次前向传播中预测整个令牌块，以目标模型的隐藏状态为条件。与 Eagle-3 的自回归草稿不同，DFlash 使用非因果注意力掩码，使得每个查询同时关注验证器的隐藏状态和掩码令牌嵌入，一次产生所有草稿令牌。这种块并行方法在同步请求上可以产生比 Eagle-3 大 2-3 倍的加速。草稿模型使用 Qwen3 风格的 Transformer 层，但可以与任何支持的验证器配对。

## 工作原理

### 架构

![DFlash 架构](../../assets/dflash_architecture.png)

目标模型从输入序列产生隐藏状态（融合的目标上下文特征）和解码令牌。这些与掩码令牌嵌入结合，通过一组草稿层，每个草稿层由双向注意力（使用 KV 缓存）和 MLP 组成。草稿层在单次前向传播中一起处理上下文特征和掩码令牌。输出通过目标 LM 头投影，产生用于投机解码的词汇 logits。

### 锚点机制

1. **选择锚点：** 在序列中选择位置
2. **从锚点预测：** 在单次前向传播中从每个锚点生成一个令牌块
3. **验证块：** 目标模型验证预测的块
4. **接受有效令牌：** 使用最长的有效前缀

### 从锚点采样

DFlash 支持两种采样模式，由 `sample_from_anchor` 配置字段控制：

- **`False`（DFlash 默认）**：锚点是奖励令牌，仅掩码位置进行预测。Slot 0 不训练。产生 `block_size - 1` 个投机令牌。

- **`True`（[DSpark](dspark.md) 默认）**：从锚点和所有掩码位置采样。所有 slot 预测未来令牌并进行训练。产生 `block_size` 个投机令牌。

**训练：** 使用 `--sample-from-anchor` / `--no-sample-from-anchor` 标志覆盖算法特定的默认值。

## 预训练模型

预训练的 DFlash 投机者模型可在 HuggingFace 上从 [RedHatAI speculator models 集合](https://huggingface.co/collections/RedHatAI/speculator-models)获取。

## 研究与引用

DFlash 基于 Z Lab 的研究：[DFlash 项目页面](https://z-lab.ai/projects/dflash/) | [arXiv 论文](https://arxiv.org/abs/2602.06036)

```bibtex
@article{chen2026dflash,
  title={DFlash: Block Diffusion for Flash Speculative Decoding},
  author={Chen, Jian and Liang, Yesheng and Liu, Zhijian},
  journal={arXiv preprint arXiv:2602.06036},
  year={2026}
}
```

## 参见

- [DSpark](dspark.md) — 在 DFlash 基础上增加了顺序 Markov 头和置信度头
- [训练投机者](../tutorials/train.md) — 分步训练指南