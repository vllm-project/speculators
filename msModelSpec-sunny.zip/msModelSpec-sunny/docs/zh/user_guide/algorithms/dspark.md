# DSpark

DSpark 在相同的块并行草稿骨干上扩展了 [DFlash](dflash.md)，增加了两个头：一个低秩 Markov 头，根据之前的令牌偏置每个草稿位置，以及一个置信度头，预测逐位置接受概率。纯块并行草稿在块内的令牌之间没有依赖关系，因此接受率在块末尾衰减——Markov 头恢复了这种依赖关系，置信度信号指示块值得验证的程度。草稿模型继承自 DFlash，因此架构和训练流程在其他方面保持不变，并且可以与任何支持的验证器配对。服务使用 vLLM 自己的 `dspark` 方法（在 `--speculative-config` 中使用 `"method": "dspark"`）。

## 工作原理

### Markov 头

该头向 DFlash logits 添加一个低秩 logit 偏置 `B = W1 @ W2`：`W1` 将前一个块令牌（验证器词汇表）嵌入到 `markov_rank` 维度，`W2` 投影到草稿词汇表。三种变体可用：

- **`vanilla`（默认）**：仅来自前一个令牌的偏置
- **`gated`**：由骨干隐藏状态门控的偏置
- **`rnn`**：在块内跨位置传递的循环状态

设置 `--markov-rank 0` 禁用该头，保留纯 DFlash 草稿。

### 置信度头

一个线性头从骨干隐藏状态预测每个位置的接受概率，当设置 `--confidence-head-with-markov` 时，与 Markov 前一个令牌嵌入拼接。使用由 `--confidence-head-alpha` 加权的 BCE 项进行训练。

## 关键参数

| 参数                           | 默认值     | 说明                               |
| ------------------------------ | ---------- | ---------------------------------- |
| `--markov-rank`                | 256        | Markov logit 偏置的低秩维度（0 禁用头） |
| `--markov-head-type`           | `vanilla`  | 顺序头变体：`vanilla`、`gated` 或 `rnn` |
| `--enable-confidence-head`     | 启用       | 附加逐位置接受头                   |
| `--confidence-head-with-markov`| 启用       | 将 Markov 前一个令牌嵌入输入置信度头 |
| `--confidence-head-alpha`      | 1.0        | 置信度头 BCE 项的权重              |

所有 DFlash 参数（`--block-size`、`--max-anchors`、`--num-layers` 等）同样适用。

## 预训练模型

预训练的 DSpark 投机者模型可在 HuggingFace 上从 [RedHatAI speculator models 集合](https://huggingface.co/collections/RedHatAI/speculator-models)获取。

## 研究与引用

DSpark 基于 DeepSeek 的研究：[arXiv 论文](https://arxiv.org/abs/2607.05147)

```bibtex
@article{cheng2026dspark,
  title={DSpark: Confidence-Scheduled Speculative Decoding with Semi-Autoregressive Generation},
  author={Cheng, Xin and Yu, Xingkai and Shao, Chenze and Li, Jiashi and Xiong, Yunfan and Qian, Yi and Zhu, Jiaqi and Ma, Shirong and Zhang, Xiaokang and Ye, Jiasheng and others},
  journal={arXiv preprint arXiv:2607.05147},
  year={2026}
}
```

## 参见

- [DFlash](dflash.md) — DSpark 扩展的基础算法
- [训练投机者](../tutorials/train.md) — 分步训练指南