# P-EAGLE

P-EAGLE（并行 EAGLE）扩展了 Eagle-3，实现了并行多令牌预测。P-EAGLE 不是自回归地一次草拟一个令牌，而是并行预测多个令牌。它在训练期间使用条件丢弃令牌（COD）采样以实现内存效率，并使用继承自 Eagle-3 的 Llama 风格 Transformer 层。它可以与任何支持的验证器模型配对。

## 工作原理

### 架构

P-EAGLE 建立在 Eagle-3 架构之上：目标模型在选定层产生隐藏状态，这些状态被拼接、投影并通过 Llama 风格解码器层。关键区别在于 P-EAGLE 增加了**多个预测深度**——在每个位置，模型不仅预测下一个令牌，还并行预测后续多个令牌。每个深度级别 d 为序列中的位置（锚点 + d）进行预测。

### COD 采样

![COD 采样](../../assets/peagle_cod_sampling.png)

朴素地训练并行多深度模型需要与 `num_depths × sequence_length` 成比例的内存。P-EAGLE 使用**条件丢弃令牌（COD）采样**来降低此成本：

- 深度 0 保留所有 n 个位置
- 深度 d 保留大约 n × r^d 个位置，其中 r 是 `down-sample-ratio`
- 最小保留下限（`down-sample-ratio-min`）防止在深层过度采样

这种几何衰减意味着更深层的预测在每个批次上训练更少的位置，保持内存使用可控，同时仍然学习预测多个后续令牌。

### 推理过程

1. P-EAGLE 在单次传播中跨所有深度并行草拟多个令牌
2. 目标模型在单次前向传播中验证所有草稿令牌
3. 接受最长的正确前缀
4. 从最后一个被接受的令牌重复

## 关键参数

| 参数                       | 默认值 | 说明                          |
| -------------------------- | ------ | ----------------------------- |
| `--num-layers`             | 4      | 草稿 Transformer 层数         |
| `--num-depths`             | 4      | 并行预测深度数                |
| `--down-sample-ratio`      | 0.7    | COD 采样的几何衰减比率         |
| `--down-sample-ratio-min`  | 0.2    | COD 采样的最小保留下限         |
| `--no-norm-before-residual`| —      | 禁用残差连接前的归一化         |

## 预训练模型

目前没有可用的预训练 P-EAGLE 模型。您可以使用下面链接的教程训练自己的模型。

## 研究与引用

P-EAGLE 基于 AWS AI Labs 的研究：[arXiv 论文](https://arxiv.org/abs/2602.01469)

```bibtex
@article{hui2026peagle,
  title={P-EAGLE: Parallel-Drafting EAGLE with Scalable Training},
  author={Hui, Mude and Huang, Xin and Salas, Jaime Campos and Sun, Yue and Pemberton, Nathan and Song, Xiang and Khetan, Ashish and Karypis, George},
  journal={arXiv preprint arXiv:2602.01469},
  year={2026}
}
```

## 参见

- [训练投机者](../tutorials/train.md) — 分步训练指南