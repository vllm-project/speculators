# MTP（多令牌预测）

MTP 是一种投机解码方法，使用模型自身的原生多令牌预测头来草拟多个后续令牌，然后由目标模型在单次前向传播中验证。与 Eagle-3 和 DFlash 从头训练草稿模型不同，MTP 微调从模型预先存在的 MTP 层开始——将它们转换为 speculators 格式，在领域特定数据上微调，并将改进的权重拼接回去。这种方法适用于具有原生 MTP 支持的模型，如 Qwen3-Next 和 Qwen3.5。

## 工作原理

### 架构

MTP 头由单个预测层组成，在每个投机步骤接收两个输入：验证器的隐藏状态和来自真实输入的令牌嵌入。这些分别归一化、拼接并投影到模型的隐藏维度，然后通过标准解码器层（注意力 + MLP）。输出隐藏状态递归地输入到下一步，而共享的 LM 头在每一步产生草稿 logits。

### 训练过程

1. **转换：** 从模型检查点提取原生 MTP 头，使用 `MTPConverter` 转换为 speculators 格式
2. **训练：** 在领域特定数据上微调 MTP 层。在每一步 k，模型在给定位置 t 的验证器隐藏状态和位置 t+k 的真实令牌嵌入的情况下预测令牌 t+k+1。每步损失使用指数衰减加权（默认 beta=0.6），遵循 FastMTP 公式 2
3. **拼接：** 将微调后的 MTP 权重合并回原始验证器检查点用于部署

只有 MTP 层是可训练的——`embed_tokens` 和 `lm_head` 被冻结并与验证器共享。

## 研究与引用

MTP 微调基于腾讯的 FastMTP 方法：[FastMTP 仓库](https://github.com/Tencent-BAC/FastMTP) | [arXiv 论文](https://arxiv.org/abs/2509.18362)

```bibtex
@article{cui2025fastmtp,
  title={FastMTP: Accelerating Multi-Token Prediction via Efficient Speculative Decoding},
  author={Cui, Hao and Diao, Hailin and Wu, Jian and Cheng, Yu},
  journal={arXiv preprint arXiv:2509.18362},
  year={2025}
}
```

## 参见

- [训练投机者](../tutorials/train.md) — 分步训练指南
- [vLLM Recipes](https://recipes.vllm.ai/) — 服务 MTP 模型的部署命令