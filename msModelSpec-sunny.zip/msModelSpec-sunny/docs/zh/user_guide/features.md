# 特性

Speculators 旨在使训练和部署投机解码模型变得快速、可扩展且易于集成到现有工作流中。以下是一些关键特性。

## 使用 FSDP 的分布式训练

Speculators 通过 PyTorch 全分片数据并行（FSDP）支持多 GPU 训练。模型参数按层分片，使用混合精度策略——参数为 bfloat16，梯度归约为 float32——分布式检查点自动处理跨 rank 的保存/恢复。

## 草稿词汇表支持

草稿模型使用缩减词汇表以获得更快的推理速度。Speculators 自动从数据准备期间收集的令牌频率统计中构建词汇映射（`t2d` 和 `d2t` 张量），选择最频繁的令牌用于草稿词汇表。也可以手动提供预构建的映射。

## 多后端指标记录

训练指标可以记录到 TensorBoard、Weights & Biases、TrackIO 和 MLflow——可单独或同时使用，以便您使用首选的实验跟踪工具。

## 自动聊天模板检测

在数据准备期间，Speculators 自动检测助手响应边界以构建损失掩码。它首先尝试 HuggingFace 原生的 `assistant_tokens_mask` 支持，然后回退到基于正则表达式的模式检测——包括从推理模型中去除 ` thinking` 块。大多数模型无需手动配置模板。

## 高性能 Flex Attention

[Eagle-3](algorithms/eagle3.md) 和 [DFlash](algorithms/dflash.md) 模型都使用 PyTorch 的 `flex_attention` 配合 `BlockMask` 实现高效、结构化的注意力模式（因果、文档感知和基于锚点）。Eagle-3 的前向传播使用 `torch.compile` 包装以进一步优化运行时。

## 高效序列打包

多打包批次采样器使用 LPT（最长处理时间优先）装箱算法将可变长度序列打包成批次，最大化 GPU 利用率同时遵守每设备令牌限制。这避免了简单填充带来的计算浪费。

## 检查点恢复

训练自动从最新的检查点恢复，恢复模型权重、优化器状态和调度器状态。检查点跟踪器记录最佳验证损失，并维护到最佳检查点的符号链接，便于模型选择。

## 与 vLLM 的无缝集成

训练好的模型以特殊的 speculators 格式保存，vLLM 可以直接加载。将 vLLM 指向检查点或 HuggingFace 模型，它会自动检测投机者，与目标模型配对，并启用投机解码——无需额外配置。

## 模型转换

Speculators 可以将来自第三方仓库（EAGLE v1/v2/v3、HASS）的预训练模型转换为 Speculators 格式，以便直接部署到 vLLM。

---

有关涵盖完整工作流程的实践指南，请参见[教程](tutorials/index.md)。