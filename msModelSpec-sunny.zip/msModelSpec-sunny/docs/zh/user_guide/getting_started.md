# 入门指南

## 什么是投机解码？

投机解码是一种在不改变输出的情况下加速 LLM 推理的技术。一个小而快的**草稿模型**（"投机者"）一次提议多个令牌，然后更大的**目标模型**在单次前向传播中验证它们。被接受的令牌保证来自与目标模型自己生成相同的分布，因此加速是无损的。

## 使用 vLLM 服务投机者

尝试投机解码最快的方法是使用 [vLLM](https://docs.vllm.ai/en/latest/getting_started/quickstart/) 服务预训练的投机者：

```bash
vllm serve RedHatAI/Qwen3-8B-speculator.eagle3
```

vLLM 从模型配置中读取信息，加载投机者和目标模型，并自动启用投机解码。更多选项请参见[在 vLLM 中服务](tutorials/serve_vllm.md)教程。

## 预训练投机者模型

在 Hugging Face 上浏览完整的即用型投机者模型集合：

**[RedHatAI/speculator-models](https://huggingface.co/collections/RedHatAI/speculator-models)**

有关我们团队端到端训练和验证的模型列表，请参见[支持的模型表](../index.md#supported-models)。

## 支持的算法

Speculators 支持多种投机解码算法：

- **[Eagle-3](algorithms/eagle3.md)**
- **[DFlash](algorithms/dflash.md)**

有关如何选择的帮助，请参见[算法决策指南](algorithms/decision_guide.md)。

## 训练您自己的投机者

如果您的目标模型没有可用的预训练投机者，您可以使用 Speculators 训练一个。训练需要目标模型的内部隐藏状态，这些状态通过使用 vLLM 服务目标模型来提取。该库支持在线和离线训练模式：

- **在线训练** — 训练期间即时生成隐藏状态。更容易上手，磁盘使用更少。
- **离线训练** — 预先生成并缓存隐藏状态。
- **混合训练** — 首个轮次即时生成隐藏状态并缓存，后续轮次重用。

### 教程

- [训练投机者](tutorials/train.md) — 推荐的起点。涵盖 Eagle-3、P-EAGLE、DFlash、DSpark 和 MTP 的所有三种模式
- [评估模型性能](tutorials/evaluating_performance.md) — 对训练好的投机者进行基准测试
- [响应重新生成](tutorials/response_regeneration.md) — 提高训练数据质量

参见[教程](tutorials/index.md)部分中的所有教程。