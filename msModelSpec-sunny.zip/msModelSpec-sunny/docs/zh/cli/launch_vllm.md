# launch_vllm.py

启动 vLLM 推理服务，用于在线训练或离线草稿模型隐藏状态生成。

## 基本用法

```bash
python scripts/launch_vllm.py meta-llama/Llama-3.1-8B-Instruct 
```

## 参数

### 位置参数

- **`model`**（字符串，必需）要提取隐藏状态的模型名称或路径。

### msModelSpec‑Dev 参数

- **`--hidden-states-path`**（字符串，默认值：`/tmp/hidden_states`）初始缓存隐藏状态的目录。注意：隐藏状态随后可能被训练/离线数据生成移动或删除,建议显示指定并保证目录存在且有足够空间。

- **`--target-layer-ids`**（整数列表，默认值：自动选择）用选择从主模型的哪几层捕获隐藏状态。注意：如果启用了 `--include-last-layer`（默认启用），模型的最后一层将追加到此列表中。默认值：`[2, num_layers//2, num_layers-3]`

  **重要提示：** 如果设置了此参数，则必须将相同的层 ID（**排除**最后一层）传递给训练脚本的 `--target-layer-ids` 参数——训练仅使用辅助层。对于下面的[完整示例](#完整示例)，即 `--target-layer-ids 5 20 40`。

- **`--include-last-layer` / `--no-include-last-layer`**（标志，默认值：`True`）将最后一层（`num_hidden_layers`）追加到 `target_layer_ids` 用于验证器隐藏状态提取。

- **`--dry-run`**（标志）打印将要执行的命令而不实际运行。

### vLLM 参数

`--` 之后的所有参数都直接传递给 vLLM。常见的 vLLM 参数包括：

- `--port`：服务器端口（默认值：`8000`）
- `--data-parallel-size`：数据并行实例数
- `--tensor-parallel-size`：张量并行的 GPU 数
- `--gpu-memory-utilization`：GPU 内存利用率（0.0 到 1.0）
- `--max-model-len`：最大模型上下文长度
- `--trust-remote-code`：允许执行自定义模型代码

完整的选项列表请参见 [vLLM CLI 文档](https://docs.vllm.ai/en/latest/cli/)。

## 完整示例

```bash
python scripts/launch_vllm.py \
  meta-llama/Llama-3.1-70B-Instruct \
  --hidden-states-path /data/hidden_states \
  --target-layer-ids 5 20 40 80 \
  -- --data-parallel-size 2 --tensor-parallel-size 4 \
  --port 8000
```