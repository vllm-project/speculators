# prepare_data.py

准备用于训练草稿模型的数据，通过以下步骤：

1. 应用聊天模板并对每个样本进行分词
2. 为每个样本生成损失/助手掩码
3. 记录令牌频率统计信息

输出是一个处理后的数据集，可用于在线训练或离线隐藏状态生成。

## 基本用法

```bash
python scripts/prepare_data.py \
  --model meta-llama/Llama-3.1-8B-Instruct \
  --data sharegpt \
  --output ./training_data \
  --max-samples 5000
```

## 参数

### 模型参数

- **`--model`**（字符串，必需）目标模型的 HuggingFace 模型 ID 或本地路径。

  示例：`meta-llama/Llama-3.1-8B-Instruct`

- **`--trust-remote-code`**（标志）允许在加载目标模型的处理器时执行来自 HF Hub 的代码。

### 数据参数

- **`--data`**（字符串，必需，可重复）训练数据的路径。可以是 HuggingFace 数据集名称或本地路径。多次使用可指定多个数据集。

  示例：`--data sharegpt --data ./custom_data.jsonl`

  输入对话应在 `conversations` 列中提供。也支持包含单独工具列的工具调用数据集，如 [llamafactory/reason-tool-use-demo-1500](https://huggingface.co/datasets/llamafactory/reason-tool-use-demo-1500) 和 [interstellarninja/hermes_reasoning_tool_use](https://huggingface.co/datasets/interstellarninja/hermes_reasoning_tool_use) 所示。

- **`--seq-length`**（整数，默认值：`8192`）每个样本的最大序列长度。较长的样本将被截断。

- **`--max-samples`**（整数，默认值：`None`）要处理的最大样本数。如果为 `None`，则处理所有样本。

- **`--token-freq-path`**（字符串，默认值：`{output}/token_freq.pt`）保存令牌频率分布的路径。默认为输出目录中的 `token_freq.pt`。

- **`--assistant-pattern`**（字符串，默认值：`None`）用于匹配助手响应的自定义正则表达式模式。如果未提供，则从聊天模板自动检测。

- **`--minimum-valid-tokens`**（整数，默认值：`None`）丢弃损失掩码中包含少于这么多可训练令牌的样本。

### 输出参数

- **`--output`**（字符串，必需）保存处理后数据集的目录。

- **`--overwrite`**（标志）强制重新运行预处理并覆盖输出目录中的现有内容。

### 处理参数

- **`--seed`**（整数，默认值：`0`）用于可重现性的随机种子。必须与其他脚本中使用的种子一致。

- **`--num-preprocessing-workers`**（整数，默认值：`8`）用于数据集预处理的 CPU 进程数。

## 完整示例

```bash
python scripts/prepare_data.py \
  --model meta-llama/Llama-3.1-8B-Instruct \
  --data sharegpt \
  --data ./custom_conversations.jsonl \
  --output ./prepared_data \
  --seq-length 4096 \
  --max-samples 10000 \
  --num-preprocessing-workers 16
```