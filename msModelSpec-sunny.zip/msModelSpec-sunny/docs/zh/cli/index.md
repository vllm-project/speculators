# CLI 参考

本页面提供 msModelSpec‑Dev 中所有命令行界面（CLI）工具的完整参考。

## 概述

msModelSpec‑Dev 为草稿模型训练工作流的不同阶段提供以下 CLI 脚本：

| 脚本                           | 用途                                               | 参考                                     |
| ------------------------------ | -------------------------------------------------- | ---------------------------------------- |
| `prepare_data.py`              | 预处理和分词数据集用于训练                          | [→ 详情](prepare_data.md)               |
| `data_generation_offline.py`   | 使用 vLLM-Ascend 离线生成隐藏状态                         | [→ 详情](data_generation_offline.md)    |
| `launch_vllm.py`               | 启动配置为提取隐藏状态的 vLLM 服务               | [→ 详情](launch_vllm.md)                |
| `train.py`                     | 使用在线或离线隐藏状态训练草稿模型               | [→ 详情](train.md)                      |
| `response_regeneration/`       | 使用 vLLM-Ascend 服务的模型重新生成数据集响应             | [→ 详情](response_regeneration.md)      |

## 常见工作流

下图展示了训练草稿模型的高层流程。离线流水线按顺序运行每个阶段，而在线流水线将隐藏状态提取和训练合并为一步。

```mermaid
flowchart TD
    subgraph optional ["可选：响应重新生成"]
        A["response_regeneration/script.py\n重新生成数据集响应以改进模型对齐"]
    end

    subgraph offline ["离线流水线"]
        B["prepare_data.py\n分词并格式化数据集"]
        C["launch_vllm.py\n启动 vLLM 服务器"]
        D["data_generation_offline.py\n从验证器提取隐藏状态并缓存到磁盘"]
        E["train.py \n在保存的隐藏状态上训练草稿模型"]
    end

    subgraph online ["在线流水线"]
        F["prepare_data.py\n分词并格式化数据集"]
        G["launch_vllm.py\n启动 vLLM 服务器"]
        H["train.py \n一步完成隐藏状态提取和训练"]
    end

    A -- "JSONL 对话" --> B
    A -- "JSONL 对话" --> F
    B --> C --> D -- "包含 {hidden_states} 的\nhs_i.safetensors 文件" --> E
    F --> G --> H

    click B "prepare_data/" _self
    click F "prepare_data/" _self
    click C "launch_vllm/" _self
    click G "launch_vllm/" _self
    click D "data_generation_offline/" _self
    click E "train/" _self
    click A "response_regeneration/" _self
    click H "train/" _self
```