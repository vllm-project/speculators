# response_regeneration

使用 vLLM 服务的模型重新生成现有数据集中的助手回复。给定一个包含对话的数据集（如 Magpie、UltraChat、GSM8K），此流水线提取对话轮次，逐轮针对模型自身的先前输出重新生成每个助手回复，并产生预分词化的训练样本。对于多轮对话，每轮都以重新生成的历史为条件，产生在策略训练数据。

该流水线包含两个脚本：

| 脚本           | 用途                                       |
| -------------- | ------------------------------------------ |
| `run_all.sh`   | 端到端流水线：启动 vLLM、重新生成回复、停止 |
| `script.py`    | 针对正在运行的 vLLM 服务器的独立回复重新生成 |

## run_all.sh

编排整个流水线：启动 vLLM 服务器（支持可选的数据/张量并行），为数据集重新生成回复，然后停止服务器。使用 vLLM 内置的数据并行（`--data-parallel-size`）实现多 GPU 扩展和自动负载均衡。

### 基本用法

```bash
./scripts/response_regeneration/run_all.sh \
  --model "meta-llama/Llama-3.3-70B-Instruct" \
  --dataset magpie
```

### 参数

- **`--model`**（字符串，必需）用于服务和生成的模型。
- **`--gpus`**（字符串，默认值：所有可见 GPU）逗号分隔的 GPU ID（设置 `CUDA_VISIBLE_DEVICES`）。
- **`--port`**（整数，默认值：`8000`）服务器端口。
- **`--dp-size`**（整数）数据并行副本数（映射到 vLLM 的 `--data-parallel-size`）。
- **`--tp-size`**（整数）每个副本的张量并行大小（映射到 vLLM 的 `--tensor-parallel-size`）。
- **`--max-model-len`**（整数）最大模型上下文长度（传递给 `vllm serve --max-model-len`）。
- **`--reasoning-parser`**（字符串）vLLM 服务器的推理解析器（传递给 `vllm serve --reasoning-parser`）。
- **`--keep-server`**（标志）处理完成后不停止 vLLM 服务器。
- **`--tool-call-parser`**（字符串）vLLM 工具调用解析器（例如 `hermes`、`llama3_json`）。向服务器添加 `--enable-auto-tool-choice --tool-call-parser`；工具调用重新生成时需要此参数，否则工具调用将以原始文本形式到达而不会被重新生成为工具。

所有其他参数都会传递给 `script.py`。

### 完整示例

```bash
./scripts/response_regeneration/run_all.sh \
  --model "meta-llama/Llama-3.3-70B-Instruct" \
  --dp-size 4 --tp-size 2 \
  --dataset magpie \
  --limit 1000 \
  --concurrency 128 \
  --max-tokens 4096
```

## script.py

从数据集中提取对话轮次，通过 vLLM 聊天补全端点逐轮重新生成每个助手回复，并写出预分词化的训练样本，在损失掩码中标记生成边界。

### 特性

- **多轮支持** — 检测 `messages`/`conversations` 字段，并针对模型自身的先前回复重新生成每个助手轮次
- **从 vLLM 服务器自动检测模型**（无需指定 `--model`）
- **恢复能力**，可跳过已处理的对话
- **异步处理**，具有可配置的并发度
- **自动重试**，对瞬时故障使用指数退避

### 基本用法

```bash
python scripts/response_regeneration/script.py --dataset magpie
```

### 参数

#### 数据参数

- **`--dataset`**（字符串，默认值：`ultrachat`）要处理的数据集预设。
- **`--split`**（字符串，默认值：预设特定）数据集分割。
- **`--subset`**（字符串，默认值：预设特定）数据子集/配置名称。
- **`--limit`**（整数，默认值：`None`）处理 N 行后停止。
- **`--language-filter`**（字符串，默认值：`None`）仅处理语言匹配此值的行（例如 `EN`）。

#### 服务器参数

- **`--endpoint`**（字符串，默认值：`http://127.0.0.1:8000/v1/chat/completions`）vLLM 聊天补全端点。
- **`--model`**（字符串，默认值：`None`）vLLM 暴露的模型名称。如果未指定，则从服务器自动检测。

#### 生成参数

- **`--concurrency`**（整数，默认值：`64`）向 vLLM 服务器的最大并发请求数。
- **`--max-tokens`**（整数，默认值：`8192`）生成的最大令牌数。
- **`--sampling-params`**（字符串，默认值：`None`）合并到每个聊天补全请求中的 JSON 对象。
- **`--max-retries`**（整数，默认值：`3`）每个请求在瞬时 HTTP 故障时的最大重试次数。

#### 输出参数

- **`--outfile`**（字符串，默认值：自动生成）输出 JSONL 路径。
- **`--resume`**（标志）跳过输出文件中已存在的对话。

## 支持的预设数据集

来自共享数据集注册表的数据集预设：

| 数据集               | HuggingFace ID                                    | 默认分割     |
| -------------------- | ------------------------------------------------- | ------------ |
| `sharegpt`           | `Aeala/ShareGPT_Vicuna_unfiltered`                | `train`      |
| `ultrachat`          | `HuggingFaceH4/ultrachat_200k`                    | `train_sft`  |
| `gsm8k`              | `openai/gsm8k`                                    | `train`      |
| `magpie`             | `Magpie-Align/Magpie-Llama-3.1-Pro-300K-Filtered` | `train`      |
| `nemotron`           | `nvidia/Llama-Nemotron-Post-Training-Dataset`     | `chat`       |
| `open-perfectblend`  | `mlabonne/open-perfectblend`                      | `train`      |
| `hermes-fc`          | `NousResearch/hermes-function-calling-v1`         | `train`      |

## 输出格式

行是预分词化的，可直接用于训练：每个目标生成一行，包含目标所依赖的提示及其生成的令牌。

```json
{
  "id": "conv-abc_gen0",
  "primary_id": "conv-abc",
  "input_ids": [151644, 872, ...],
  "loss_mask": [0, 0, ..., 1, 1],
  "text": "<|im_start|>user\nWhat is the capital of France?<|im_end|>\n<|im_start|>assistant\nThe capital of France is Paris.<|im_end|>",
  "metadata": {
    "idx": 0,
    "finish_reason": "stop",
    "is_tool_call": false,
    "usage": {...},
    "endpoint": "http://127.0.0.1:8000/v1/chat/completions",
    "sampling_params": {...}
  }
}
```