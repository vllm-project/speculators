# data_generation_offline.py

通过从正在运行的 vLLM 服务器提取隐藏状态，生成草稿模型的训练数据。通过 OpenAI 兼容 API 连接到 vLLM 端点，并将输出保存为单独的 `.safetensors` 文件，用于离线训练。

## 特性

- **自动恢复** — 检测输出目录中现有的 `.safetensors` 文件，跳过已完成的样本，中断后可以恢复运行而无需重新处理。
- **错误处理与自动重试** — 失败的请求会自动重试最多 `--max-retries` 次。默认情况下会跳过仍然失败的样本，使数据集的其余部分能够完成。
- **连续失败检测** — 在连续 `--max-consecutive-errors` 次失败后提前中止，避免在服务器不可达时静默消耗数据集。
- **异步并发** — 通过 `--concurrency` 控制并发向 vLLM 服务器发送多个请求，实现高吞吐量。
- **输出验证** — 可选的 `--validate-outputs` 标志，验证保存的隐藏状态是否与预期的令牌 ID 和序列长度匹配。

## 基本用法

```bash
python scripts/data_generation_offline.py \
  --preprocessed-data ./preprocessed_dataset \
  --output ./training_data \
  --max-samples 5000
```

## 参数

### 模型参数

- **`--endpoint`**（字符串，默认值：`http://localhost:8000/v1`）用于生成隐藏状态的 vLLM 实例地址。vLLM 实例必须配置为支持隐藏状态提取（参见 [launch_vllm.py](launch_vllm.md)）。

- **`--model`**（字符串，默认值：`None`）目标模型的 HuggingFace 模型 ID 或本地路径。仅用于验证——模型会从 vLLM 端点自动检测。

### 数据参数

- **`--preprocessed-data`**（字符串，必需）预处理数据集的路径（由 [prepare_data.py](prepare_data.md) 生成）。

- **`--max-samples`**（整数，默认值：`None`）要处理的最大样本数。如果为 `None`，则处理所有样本。

### 输出参数

- **`--output`**（字符串，默认值：`None`）保存生成的 `.safetensors` 文件的目录。默认为 `<preprocessed-data>/hidden_states`。

### 隐藏状态生成参数

- **`--concurrency`**（整数，默认值：`32`）同时活跃的 vLLM 请求数。异步工作线程数设置为 `2 * concurrency`。

- **`--validate-outputs`**（标志）加载生成的 safetensor 文件，验证输出令牌 ID 是否与提示令牌匹配，以及隐藏状态序列长度是否与令牌数匹配。

- **`--request-timeout`**（浮点数）每个 vLLM 请求的超时时间（秒）。

- **`--max-retries`**（整数）每个请求失败时的最大重试次数。

- **`--fail-on-error`**（标志）请求在所有重试后仍然失败时中止。默认情况下，失败的样本会被跳过。

- **`--max-consecutive-errors`**（整数，默认值：`--concurrency` 的值）在此数量的连续样本失败后中止（每个样本已重试 `--max-retries` 次）。防止在服务器宕机时静默消耗整个数据集。设置 `--fail-on-error` 时忽略。

### 多节点参数

- **`--world-size`**（整数，默认值：`1`）参与数据生成的节点数。每个节点被分配数据集的一个连续、不重叠的分块。这是节点数，而非 GPU 数。

- **`--rank`**（整数，默认值：`0`）当前节点的从零开始的索引。必须在 `[0, world-size)` 范围内。

## 完整示例

```bash
python scripts/data_generation_offline.py \
  --endpoint http://localhost:8000/v1 \
  --preprocessed-data ./preprocessed_dataset \
  --output ./hidden_states \
  --concurrency 64 \
  --validate-outputs
```