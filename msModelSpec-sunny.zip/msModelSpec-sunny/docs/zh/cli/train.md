# train.py

使用在线或离线隐藏状态训练投机者模型。支持单 GPU 和多 GPU 分布式训练。

## 基本用法

**单 NPU：**

```bash
python scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --data-path ./training_data \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 10
```

**多 NPU（DDP）：**

```bash
torchrun --standalone --nproc_per_node=4 scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --data-path ./training_data \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 10
```

**多 NPU（FSDP 分片）：**     

```bash
torchrun --standalone --nproc_per_node=4 scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --data-path ./training_data \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 10 \
  --fsdp-shard
```

## 参数

### 模型参数

- **`--verifier-name-or-path`**（字符串，必需）验证器/目标模型的 HuggingFace 模型 ID 或本地路径。
- **`--trust-remote-code`**（标志）允许在加载验证器的分词器时执行来自 HF Hub 的代码。
- **`--speculator-type`**（字符串，默认值：`"eagle3"`）要训练的投机者模型类型。选项：`eagle3`、`dflash`、`dspark`、`peagle`、`mtp`
- **`--from-pretrained`**（字符串，默认值：`""`）现有草稿检查点的路径或 HF ID，用于加载权重并继续训练。
- **`--draft-config`**（字符串，默认值：`""`）用作草稿 `transformer_layer_config` 的解码器配置。
- **`--dry-run`**（标志）构建投机者、初始化权重、保存检查点到 `--save-path`，然后在训练前退出。
- **`--num-layers`**（整数，默认值：`1`）草稿模型中的 Transformer 层数。
- **`--draft-arch`**（字符串，默认值：`"llama"`）合成的草稿解码器层的架构。选项：`llama`、`qwen3`。
- **`--draft-hidden-act`**（字符串，默认值：`"silu"`）草稿解码器层的激活函数。

### 数据参数

- **`--data-path`**（字符串，默认值：`"./data"`）处理后的训练数据目录路径。
- **`--on-missing`**（选项：`generate`|`skip`|`warn`|`raise`，默认值：`generate`）缓存隐藏状态缺失时的行为。
- **`--on-generate`**（选项：`cache`|`delete`，默认值：`"delete"`）生成新隐藏状态后的行为。
- **`--hidden-states-path`**（字符串，默认值：`{data-path}/hidden_states`）缓存隐藏状态文件的存储路径。
- **`--vllm-endpoint`**（字符串，默认值：`"http://localhost:8000/v1"`）按需生成隐藏状态的 vLLM 端点地址。
- **`--request-timeout`**（浮点数，默认值：`180.0`）每个 vLLM 请求的超时时间（秒）。
- **`--max-retries`**（整数，默认值：`3`）每个 vLLM 请求失败时的最大重试次数。
- **`--legacy-data`**（标志）**已弃用。** 使用将隐藏状态与 token_ids 一起存储的旧数据格式。
- **`--total-seq-len`**（整数，默认值：`8192`）训练批次的最大总序列长度。

### 词汇映射参数

- **`--draft-vocab-size`**（整数，默认值：`None`）草稿模型的词汇表大小。
- **`--token-freq-path`**（字符串，默认值：`{data-path}/token_freq.pt`）令牌频率分布文件的路径。
- **`--d2t-path`**（字符串，默认值：`None`）草稿到目标词汇映射文件的路径（`.npy`）。
- **`--t2d-path`**（字符串，默认值：`None`）目标到草稿词汇映射文件的路径（`.npy`）。
- **`--mask-token-id`**（整数，默认值：自动检测）用作掩码令牌的令牌 ID（用于 DFlash）。
- **`--target-layer-ids`**（整数列表，默认值：自动选择）辅助隐藏状态的层 ID 列表。

### 分布式训练参数

- **`--fsdp-shard`**（标志）使用 FSDP 在 GPU 间分片模型参数。

### 训练参数

- **`--save-path`**（字符串，默认值：`"./checkpoints"`）保存模型检查点的目录。
- **`--epochs`**（整数，默认值：`20`）训练轮数。
- **`--lr`**（浮点数，默认值：`1e-4`）学习率。
- **`--train-data-ratio`**（浮点数，默认值：`0.9`）用于训练的数据比例，其余用于验证。
- **`--no-resume-from-checkpoint`**（标志）禁用自动检查点恢复。
- **`--logger`**（字符串，默认值：`""`）指标记录后端。选项：`trackio`、`wandb`、`tensorboard`、`mlflow`。
- **`--log-dir`**（字符串，默认值：`"./logs"`）保存训练日志的目录。
- **`--run-name`**（字符串，默认值：`None`）训练运行的名称。
- **`--seed`**（整数，默认值：`42`）用于可重现性的随机种子。
- **`--hidden-states-dtype`**（字符串，默认值：`"bfloat16"`）数据加载器隐藏状态和自动类型转换计算的数据类型。
- **`--deterministic-cuda`**（标志）启用确定性 CUDA 操作。

### 优化器参数

- **`--optimizer`**（字符串，默认值：`"muon"`）使用的优化器。选项：`adamw`、`muon`。
- **`--weight-decay`**（浮点数，默认值：`0.01`）AdamW 优化器的权重衰减。
- **`--muon-lr`**（浮点数，默认值：`10*lr`）Muon（2D 权重）组的学习率。
- **`--muon-momentum`**（浮点数，默认值：`0.95`）Muon 优化器的动量。
- **`--muon-weight-decay`**（浮点数，默认值：`0.1`）Muon 优化器的权重衰减。
- **`--muon-ns-steps`**（整数，默认值：`5`）Muon 的 Newton-Schulz 步数。
- **`--muon-adjust-lr-fn`**（字符串，默认值：`"match_rms_adamw"`）Muon 学习率调整策略。

### Eagle3 特定参数

- **`--norm-before-residual` / `--no-norm-before-residual`**（标志，默认值：`True`）切换残差连接前的归一化。
- **`--embed-requires-grad` / `--no-embed-requires-grad`**（标志，默认值：`False`）是否训练嵌入层权重。
- **`--norm-before-fc` / `--no-norm-before-fc`**（标志，默认值：Eagle3 为 `True`，否则为 `False`）在全连接投影前对拼接的辅助隐藏状态应用 RMSNorm。
- **`--fc-norm`**（标志，默认值：`False`）对每个辅助隐藏状态应用逐层 RMSNorm。
- **`--norm-output` / `--no-norm-output`**（标志，默认值：Eagle3 为 `True`，否则为 `False`）在 TTT 步骤间反馈归一化后的隐藏状态。
- **`--ttt-steps`**（整数，默认值：`3`）测试时训练步数。
- **`--ttt-step-loss-decay`**（浮点数，默认值：`1.0`）测试时训练步的损失衰减因子。

### P-EAGLE 特定参数

- **`--num-depths`**（整数，默认值：`8`）并行预测深度数。
- **`--down-sample-ratio`**（浮点数，默认值：`0.7`）COD 采样的几何衰减比率。
- **`--down-sample-ratio-min`**（浮点数，默认值：`0.2`）COD 采样的最小保留比率。

### 注意力后端参数

- **`--draft-attn-impl`**（字符串，默认值：`"simple_flex_attention"`）草稿层的注意力实现。选项：`simple_flex_attention`、`sdpa`、`eager`。

### DFlash 特定参数

- **`--block-size`**（整数，默认值：`8`）DFlash 模型的块大小。
- **`--sample-from-anchor` / `--no-sample-from-anchor`**（布尔值，默认值：算法特定）是否从锚点位置采样。
- **`--max-anchors`**（整数，默认值：`3072`）DFlash、DSpark 和 P-EAGLE 训练的最大锚点位置数。
- **`--dflash-decay-gamma`**（浮点数，默认值：`4.0`）DFlash 损失加权的衰减 gamma。
- **`--per-position-loss-weight`**（字符串，默认值：`"fixed-exp-decay"`）逐位置损失加权方案。
- **`--dpace-alpha`**（浮点数，默认值：`0.5`）D-PACE 损失的置信度平滑常数。

### DSpark 特定参数

- **`--markov-rank`**（整数，默认值：`256`）Markov logit 偏置头的低秩维度。
- **`--markov-head-type`**（字符串，默认值：`"vanilla"`）顺序头变体。
- **`--enable-confidence-head` / `--no-enable-confidence-head`**（标志，默认值：`True`）附加逐位置接受置信度头。
- **`--confidence-head-with-markov` / `--no-confidence-head-with-markov`**（标志，默认值：`True`）将 Markov 前一个令牌嵌入输入置信度头。
- **`--confidence-head-alpha`**（浮点数，默认值：`1.0`）置信度头 BCE 项的权重。

### 滑动窗口注意力参数

- **`--sliding-window`**（整数，默认值：`2048`）滑动窗口注意力层的窗口大小。
- **`--full-attention-indices`**（整数列表，默认值：无）应使用全注意力的草稿层索引。
- **`--sliding-window-non-causal`**（标志）在草稿块中使用非因果（双向）掩码。

### 数据加载器参数

- **`--num-workers`**（整数，默认值：`12`）数据加载器工作进程数。
- **`--prefetch-factor`**（整数，默认值：`4`）每个工作进程预取批次数。
- **`--noise-std`**（浮点数，默认值：`0.05`）隐藏状态噪声增强的标准差。

### 检查点参数

- **`--checkpoint-freq`**（整数，默认值：`1`）每 N 轮保存一个检查点。
- **`--save-best`**（标志）保存指向验证损失最低的检查点的符号链接。

### 学习率调度器参数

- **`--scheduler-type`**（字符串，默认值：`"linear"`）学习率调度器类型。选项：`linear`、`cosine`、`none`。
- **`--scheduler-warmup-steps`**（整数，默认值：`None`）调度器的预热步数。
- **`--scheduler-warmup-ratio`**（浮点数，默认值：`None`）预热步数占总调度步数的比例。
- **`--scheduler-total-steps`**（整数，默认值：`None`）调度器的总训练步数。
- **`--scheduler-num-cosine-cycles`**（浮点数，默认值：`0.5`）余弦调度器的余弦周期数。

## 示例

### 在线训练

```bash
python scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --data-path ./training_data \
  --vllm-endpoint http://localhost:8000/v1 \
  --on-missing generate \
  --on-generate delete \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 10 \
  --lr 3e-5
```

### 离线训练

```bash
python scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --data-path ./training_data \
  --hidden-states-path ./hidden_states \
  --on-missing raise \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 10 \
  --lr 3e-5
```

### 混合训练（首个轮次缓存）

```bash
python scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --data-path ./training_data \
  --hidden-states-path ./hidden_states \
  --vllm-endpoint http://localhost:8000/v1 \
  --on-missing generate \
  --on-generate cache \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 10 \
  --lr 3e-5
```

### 多 GPU 训练与 WandB 日志记录

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 torchrun \
  --standalone \
  --nproc_per_node 4 \
  scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-70B-Instruct \
  --data-path ./training_data \
  --hidden-states-path ./hidden_states \
  --save-path ./checkpoints \
  --draft-vocab-size 32000 \
  --epochs 20 \
  --lr 1e-4 \
  --logger wandb \
  --run-name eagle3-llama-70b \
  --scheduler-type cosine \
  --scheduler-warmup-steps 100 \
  --checkpoint-freq 2 \
  --save-best \
  --fsdp-shard
```

### 微调预训练模型

```bash
python scripts/train.py \
  --verifier-name-or-path meta-llama/Llama-3.1-8B-Instruct \
  --from-pretrained ./pretrained_speculator \
  --data-path ./new_training_data \
  --hidden-states-path ./hidden_states \
  --save-path ./finetuned_checkpoints \
  --epochs 5 \
  --lr 5e-6
```