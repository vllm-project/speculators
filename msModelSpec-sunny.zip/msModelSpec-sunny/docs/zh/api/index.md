# API 参考

本节包含 msModelSpec‑Dev 的自动生成 Python API 文档。

!!! warning
    目前**不官方支持**直接使用 Python API，且版本之间**不保证向后兼容**。建议使用 [CLI 命令](../cli/index.md)作为与 msModelSpec‑Dev 交互的主要入口点。