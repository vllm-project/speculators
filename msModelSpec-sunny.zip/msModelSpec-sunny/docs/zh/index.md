# msModelSpec-Dev 文档

<div align="center" style="display: flex; align-items: center; justify-content: center; gap: 20px; text-align: left;">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="../assets/branding/speculators-logo-white.svg" />
    <source media="(prefers-color-scheme: light)" srcset="../assets/branding/speculators-logo-black.svg" />
    <img alt="Speculators logo" src="../assets/branding/speculators-logo-black.svg" height="64" />
  </picture>
</div>

## 概述

本仓库的建设目标为打造昇腾 NPU 原生的投机解码草稿模型训练底座。依托该工程可实现开箱即用的部署效果，同时快速支持各类新模型与前沿算法，充分适配昇腾平台显存调度优化、训练加速等专属能力。

Speculators 是一个统一的库，用于构建、训练和存储大语言模型（LLM）推理的投机解码算法，包括在 vLLM 等框架中的使用。投机解码是一种无损技术，通过使用更小、更快的草稿模型（即"投机者"）来提议令牌，然后由更大的基础模型进行验证，从而减少延迟而不影响输出质量。

投机者智能地提前起草多个令牌，基础模型在单次前向传播中验证它们。这种方法在不牺牲输出质量的前提下提升性能，因为每个被接受的令牌都保证来自与单独使用主模型相同的分布。

Speculators 通过提供生产级的端到端框架来标准化这一过程，该框架使用可复用的格式和工具来训练草稿模型。训练好的模型可以直接在 vLLM 中运行，从而在生产级推理服务器中部署投机解码。

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="../assets/branding/speculators-user-flow-dark.svg" />
    <source media="(prefers-color-scheme: light)" srcset="../assets/branding/speculators-user-flow-light.svg" />
    <img alt="Speculators user flow diagram" src="../assets/branding/speculators-user-flow-light.svg" />
  </picture>
</p>

## 主要特性

- **使用 vLLM 进行离线训练数据生成：** 利用 vLLM 生成隐藏状态。数据样本保存到磁盘，可用于草稿模型训练。
- **草稿模型训练支持：** 单层和多层草稿模型的端到端训练支持。支持 MoE、非 MoE 和视觉语言模型。
- **标准化、可扩展的格式：** 提供 Hugging Face 兼容的格式用于定义投机模型，并提供从外部研究仓库转换为标准 speculators 格式的工具，便于采用。
- **无缝 vLLM 集成：** 专为直接部署到 vLLM 而设计，实现低延迟、生产级推理，开销最小。

!!! tip
    阅读此 [vLLM 博客文章](https://blog.vllm.ai/2025/12/13/speculators-v030.html)了解更多关于 Speculators 特性的信息。

## 快速开始

要尝试投机解码模型，你可以从使用 vLLM 运行预训练模型开始。[安装 vLLM](https://docs.vllm.ai/en/latest/getting_started/installation/) 后，运行：

```bash
vllm serve RedHatAI/Qwen3-8B-speculator.eagle3
```

（或从 [RedHatAI/speculator-models](https://huggingface.co/collections/RedHatAI/speculator-models) 集合中选择另一个模型。）

在后台，这将从 Hugging Face 读取模型，解析 `speculators_config`，并同时设置投机者和验证器模型一起运行。

要为不同的验证器模型创建投机解码模型，有两种方法可供选择：

1. **训练新的投机解码模型** - 参见[入门指南](user_guide/getting_started.md)和[教程](user_guide/tutorials/index.md)。
2. **从第三方库转换现有模型**为 Speculators 格式，以便轻松部署到 vLLM - 参见[特性](user_guide/features.md)。

## 支持的模型

下表总结了我们团队端到端训练的模型：

<table>
<thead>
<tr>
<th>验证器架构</th>
<th>验证器规模</th>
<th>训练支持</th>
<th>vLLM 部署支持</th>
</tr>
</thead>
<tbody>
<tr>
<td rowspan="3">Llama</td>
<td>8B-Instruct</td>
<td><a href="https://huggingface.co/RedHatAI/Llama-3.1-8B-Instruct-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>70B-Instruct</td>
<td><a href="https://huggingface.co/RedHatAI/Llama-3.3-70B-Instruct-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
</tr>
<tr>
<td rowspan="3">Qwen3</td>
<td>8B</td>
<td><a href="https://huggingface.co/RedHatAI/Qwen3-8B-speculator.eagle3">Eagle-3</a> ✅<br/><a href="https://huggingface.co/RedHatAI/Qwen3-8B-speculator.dflash">DFlash</a> ✅<br/><a href="https://huggingface.co/RedHatAI/Qwen3-8B-speculator.peagle">P-EAGLE</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>14B</td>
<td><a href="https://huggingface.co/RedHatAI/Qwen3-14B-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>32B</td>
<td><a href="https://huggingface.co/RedHatAI/Qwen3-32B-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td rowspan="2">gpt-oss</td>
<td>20b</td>
<td><a href="https://huggingface.co/RedHatAI/gpt-oss-20b-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>120b</td>
<td><a href="https://huggingface.co/RedHatAI/gpt-oss-120b-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
  <td rowspan="4">Qwen3 MoE</td>
  <td>30B-Instruct</td>
  <td><a href="https://huggingface.co/RedHatAI/Qwen3-30B-A3B-Instruct-2507-speculator.eagle3">Eagle-3</a> ✅<br/><a href="https://huggingface.co/RedHatAI/Qwen3-30B-A3B-Instruct-2507-speculator.dflash">DFlash</a> ✅</td>
  <td>✅</td>
</tr>
<tr>
  <td>30B</td>
  <td><a href="https://huggingface.co/RedHatAI/Qwen3-30B-A3B-speculator.dflash">DFlash</a> ✅</td>
  <td>✅</td>
</tr>
<tr>
  <td>235B-Instruct</td>
  <td><a href="https://huggingface.co/RedHatAI/Qwen3-235B-A22B-Instruct-2507-speculator.eagle3">Eagle-3</a> ✅</td>
  <td>✅</td>
</tr>
<tr>
  <td>235B</td>
  <td><a href="https://huggingface.co/RedHatAI/Qwen3-235B-A22B-speculator.eagle3">Eagle-3</a> ✅</td>
  <td>✅</td>
</tr>
<td>Qwen3-VL</td>
<td>235B-A22B</td>
<td><a href="https://huggingface.co/RedHatAI/Qwen3-VL-235B-A22B-Instruct-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>Mistral Small 4</td>
<td>119B</td>
<td><a href="https://huggingface.co/RedHatAI/Mistral-Small-4-119B-2603.dflash">DFlash</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>Gemma 4</td>
<td>31B-it</td>
<td><a href="https://huggingface.co/RedHatAI/gemma-4-31B-it-speculator.eagle3">Eagle-3</a> ✅<br/><a href="https://huggingface.co/RedHatAI/gemma-4-31B-it-speculator.dflash">DFlash</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>Gemma 4 MoE</td>
<td>26B-A4B-it</td>
<td><a href="https://huggingface.co/RedHatAI/gemma-4-26B-A4B-it-speculator.eagle3">Eagle-3</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>NVIDIA Nemotron 3 Ultra</td>
<td>550B-A55B</td>
<td><a href="https://huggingface.co/RedHatAI/NVIDIA-Nemotron-3-Ultra-550B-A55B-speculator.dflash">DFlash</a> ✅</td>
<td>✅</td>
</tr>
<tr>
<td>NVIDIA Nemotron 3 Super</td>
<td>120B-A12B</td>
<td><a href="https://huggingface.co/RedHatAI/NVIDIA-Nemotron-3-Super-120B-A12B-speculator.dflash">DFlash</a> ✅</td>
<td>✅</td>
</tr>
</tbody>
</table>

✅ = 已支持，⏳ = 开发中，❌ = 暂不支持

## 安装

### 前置条件

安装前，请确保具备以下条件：

- **操作系统：** Linux 或 macOS
- **Python：** 3.10 或更高版本
- **包管理器：** pip（推荐）或 conda

### 从 PyPI 安装（推荐）

从 PyPI 安装最新的稳定版本：

```bash
pip install speculators
```

### 从源码安装

获取最新开发版本或为项目贡献代码：

```bash
git clone https://github.com/vllm-project/speculators.git
cd speculators

pip install -e .
```

如需包含额外开发工具：

```bash
pip install -e ".[dev]"
```

## 社区与支持

💬 加入 [vLLM Community Slack](https://slack.vllm.ai/) 分享您的问题、想法或建议：

- `#speculators`
- `#feat-spec-decode`

🎥 观看我们的 Office Hours 演示：[视频](https://www.youtube.com/live/2ISAr_JVGLs) | [幻灯片](https://docs.google.com/presentation/d/1s4eAb7v-rdZt8smyULBJWGXjJXrgFTZWnwqYa2-h1l4/edit?slide=id.g3365e070742_6_0#slide=id.g3365e070742_6_0)

更多社区资源，请参见[社区页面](community/index.md)。

## 下一步

- [用户指南](user_guide/index.md) - 学习如何使用 Speculators
- [入门指南](user_guide/getting_started.md) - 模型训练快速入门
- [教程](user_guide/tutorials/index.md) - 分步指导
- [API 参考](api/index.md) - Python API 文档
- [CLI 参考](cli/index.md) - 命令行工具文档

## 许可

Speculators 基于 [Apache License 2.0](https://github.com/vllm-project/speculators/blob/main/LICENSE) 许可。

## 引用

如果您在研究或项目中使用了 Speculators，请考虑引用：

```bibtex
@misc{speculators2025,
  title={Speculators: A Unified Library for Speculative Decoding Algorithms in LLM Serving},
  author={Red Hat},
  year={2025},
  howpublished={\url{https://github.com/vllm-project/speculators}},
}
```