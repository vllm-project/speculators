# msModelSpec-Dev

> 面向昇腾原生的投机解码（Speculative Decoding）草稿模型训练仓库。

## 概述

msModelSpec‑Dev 是面向投机解码草稿模型训练的专用工程仓库。
投机解码是一项可做到无损效果的大语言模型推理加速技术：由体量更小、推理速度更快的草稿模型预先生成多枚 Token 候选，再交由主基座校验模型（verifier）通过单次前向运算完成结果核验。该方案能够可无损加速大模型推理，显著降低推理时延。

本项目旨在搭建昇腾 NPU 原生适配的草稿模型训练底座。仓库支持开箱即用，可快速接入各类全新模型与前沿投机解码算法，深度适配昇腾硬件平台的显存调度优化、硬件训练加速等专属特性。

仓库内置完整端‑to‑端草稿模型训练框架，配套封装可复用的数据处理规范与工具链路；经由本仓库训练的草稿模型，能够直接对接部署至主流推理引擎。

> 本仓库代码最初基于 [vllm-project/speculators](https://github.com/vllm-project/speculators)，并在此基础上进行定制化开发。

## 核心特性

- **离线训练数据生成（基于 vLLM）**：利用 vLLM 生成隐藏状态，样本落盘后用于草稿模型训练。
- **草稿模型训练**：支持单层与多层草稿模型的端到端训练，覆盖 MoE、非 MoE 以及视觉语言模型。
- **标准化、可扩展的格式**：提供 Hugging Face 兼容的投机模型定义格式，以及将外部研究仓库转换为标准格式的工具。
- **与 vLLM 无缝集成**：训练完成的模型可直接通过 `vllm serve` 部署，实现低延迟、生产级推理。

## 支持的训练算法

| 算法 | 说明 |
| --- | --- |
| EAGLE-3 | 经典多层草稿模型训练算法，支持多种基座架构。 |
| P-EAGLE | 在 EAGLE-3 架构上扩展，通过 COD 采样实现并行多 token 预测，降低草稿延迟。 |
| DFlash | 锚定块（anchored-block）草拟算法，利用 verifier 多层辅助隐藏状态。 |
| DSpark | 在 DFlash 基础上扩展马尔可夫头与置信度头，可从 DFlash 检查点热启动。 |
| MTP Finetuning | 针对模型原生 Multi-Token Prediction 头的微调方案。 |

## 目录结构

```
.
├── docs/                  # 文档
├── examples/              # 训练、转换、评测示例脚本
├── hs_connectors/         # 隐藏状态连接器（Mooncake 等）
├── scripts/               # 评测、数据生成、训练等入口脚本
├── src/speculators/       # 核心源码
│   ├── convert/           # 模型格式转换
│   ├── data_generation/   # 训练数据生成
│   ├── models/            # 各算法草稿模型实现
│   ├── proposals/         # 提议策略
│   ├── train/             # 训练框架
│   └── utils/             # 通用工具
└── tests/                 # 单元、集成与端到端测试
```

## 快速开始

### 环境要求

- **操作系统**：Linux 或 macOS
- **Python**：3.10 及以上
- **包管理器**：pip（推荐）或 conda

### 安装

从源码安装（开发模式）：

```bash
git clone https://gitcode.com/sunny_infra/msModelSpec-Dev.git
cd msModelSpec-Dev
pip install ./hs_connectors
pip install -e .
```

包含开发工具的安装：

```bash
pip install -e ".[dev]"
```

### 验证安装

```bash
msmodelspec --version
```

或：

```python
import msmodelspec
print(msmodelspec.__version__)
```




## 许可证

本项目基于 [Apache License 2.0](./LICENSE) 许可证。
